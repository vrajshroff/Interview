

public class Card {

    private final String x;
    private final String y;

    public Card(String x, String y) {
        this.x = x;
        this.y = y;
        
}    
    
    public String getVal() {
        return x;
    }

    public String getSuite() {
        return y;
    }
    
    
}
	
    
